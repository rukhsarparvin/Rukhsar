

import jakarta.servlet.ServletException;


import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
 
  
@WebServlet("/ViewServlet")  
public class ViewServlet extends HttpServlet {  
	
    public void doGet(HttpServletRequest request, HttpServletResponse response)   
               throws ServletException, IOException {  
        
    	  response.setContentType("text/html");  
          PrintWriter out=response.getWriter();  
          out.println("<a href='index.html'>Add New Employee1</a>");  
          out.println("<h1>Employees List</h1>");  
            
          List<Emp> list=EmpDao.getAllEmployee1();  
            
          out.print("<table border='1' width='100%'");  
          out.print("<tr><th>Id</th><th>Name</th><th>Password</th><th>Email</th><th>Country</th>  <th>Edit</th><th>Delete</th></tr>");  
          for(Emp e:list){  
           out.print("</td><td>"+e.getName()+"</td><td>"+e.getPassword()+"</td> <td>"+e.getEmail()+"</td><td>"+e.getCountry()+"</td><td></td></tr>");  
          }  
          out.print("</table>");  
            
          out.close();  
      }  
  }  