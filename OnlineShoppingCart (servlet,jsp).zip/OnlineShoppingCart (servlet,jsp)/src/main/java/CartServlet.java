

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.util.ArrayList;
import java.util.List;
 import java.io.IOException;
 
 	 
	
	@WebServlet("/CartServlet")
	public class CartServlet extends HttpServlet {
		
	    public void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        int productId = Integer.parseInt(request.getParameter("productId"));
	        int quantity = Integer.parseInt(request.getParameter("quantity"));

	        Product product = Product.getProductById(productId);
	        CartItem cartItem = new CartItem(product, quantity);

	        HttpSession session = request.getSession();
	        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");
	        if (cart == null) {
	            cart = new ArrayList<>();
	        }
	        cart.add(cartItem);

	        session.setAttribute("cart.jsp", cart);
	        response.sendRedirect("products.jsp");
	    }

	     public void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        HttpSession session = request.getSession();
	        List<CartItem> cart = (List<CartItem>) session.getAttribute("cart");

	        request.setAttribute("cart", cart);
	        request.getRequestDispatcher("cart.jsp").forward(request, response);
	    }
	}
