

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


 	 
	@WebServlet("/FeedbackServlet")
	public class FeedbackServlet extends HttpServlet {
	    protected void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        String name = request.getParameter("name");
	        String email = request.getParameter("email");
	        String feedback = request.getParameter("feedback");

	        // You can store the feedback data or perform other actions here

	        request.getRequestDispatcher("feedback.jsp").forward(request, response);
	    }
	}
