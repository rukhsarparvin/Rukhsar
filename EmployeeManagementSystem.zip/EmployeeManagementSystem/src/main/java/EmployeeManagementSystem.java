 import java.sql.*;

public class EmployeeManagementSystem {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/employee";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "12345";

    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Connect to the database
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Create a statement object
            statement = connection.createStatement();

            // Create a new employee
            String createQuery = "INSERT INTO employees (name, age, department) VALUES ('John Doe', 30, 'IT')";
            statement.executeUpdate(createQuery);
            System.out.println("Employee created successfully.");

            // Retrieve all employees
            String selectQuery = "SELECT * FROM employees";
            resultSet = statement.executeQuery(selectQuery);

            // Display employee information
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                String depa = resultSet.getString("depa");

                System.out.println("ID: " + id);
                System.out.println("Name: " + name);
                System.out.println("Age: " + age);
                System.out.println("Depa: " + depa);
                System.out.println("-------------------------");
            }

            // Update an employee's information
            String updateQuery = "UPDATE employees SET depa = 'HR' WHERE id = 1";
            statement.executeUpdate(updateQuery);
            System.out.println("Employee updated successfully.");

            // Delete an employee
            String deleteQuery = "DELETE FROM employees WHERE id = 1";
            statement.executeUpdate(deleteQuery);
            System.out.println("Employee deleted successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the resources
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}



