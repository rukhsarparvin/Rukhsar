import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		String name = "rukhsar sheikhe";
		 Scanner sc = new Scanner(System.in);
		 String = sc.nextLine();
		 System.out.println("first name 11:"+);
		 
	}

}
