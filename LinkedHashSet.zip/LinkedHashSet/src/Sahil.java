import java.util.*;
public class Sahil {

	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("Tony");
		System.out.println(sb);
	
	// inserting
		//sb.insert(0,'S');
		//System.out.println(sb);
		
		sb.insert(0,"java");
		System.out.println(sb);
		
	// delete
		//sb.delete(2,3);
		//System.out.println(sb);
		
	// append
		sb.append("e");
		
	}

}
