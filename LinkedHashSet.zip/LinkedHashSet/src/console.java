import java.io.*;
public class console {

	public static void main(String[] args) {
		String str;
		char[] ch;
		Console obj = System.console();
		System.out.println("enter user name:");
		str=obj.readLine();
		System.out.println(" enter passsword:");
		ch=obj.readPassword();
		
		System.out.println("user name:"+str);
		System.out.println("password:"+ch);
		
	}

}
