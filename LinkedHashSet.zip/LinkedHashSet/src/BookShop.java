import java.util.*;
public class BookShop {

	public static void main(String[] args) {
		HashSet<String> set = new HashSet<String>();
		
		// additing element
		set.add("English");
		set.add("Hindi");
		set.add("Marathi");
		set.add("Math");
		System.out.println(set);
		
	// searching element (contains)
		if(set.contains("Hindi")) {
			//System.out.println("set contains Hindi");
		}
		if(set.contains("Hindi")) {
			//System.out.println("does not not contains");
		}
	// delete 
		set.remove("Hindi");
		System.out.println("after removing element:"+set);
			 
	}
}


