 
 const nameInput = document.getElementById("nameInput");
const ageInput = document.getElementById("ageInput");
const addStudentButton = document.getElementById("addStudent");
const studentList = document.getElementById("studentList");

addStudentButton.addEventListener("click", addStudent);

function addStudent() {
    const name = nameInput.value.trim();
    const age = parseInt(ageInput.value);

    if (name !== "" && !isNaN(age)) {
        const student = {
            name: name,
            age: age,
        };

        appendStudentToList(student);

        nameInput.value = "";
        ageInput.value = "";
    }
}

function appendStudentToList(student) {
    const studentItem = document.createElement("li");
    studentItem.innerHTML = `${student.name} - ${student.age} years
        <span class="delete" onclick="deleteStudent(this)">Delete</span>`;
    
    studentList.appendChild(studentItem);
}

function deleteStudent(deleteButton) {
    const studentItem = deleteButton.parentElement;
    studentList.removeChild(studentItem);
}
