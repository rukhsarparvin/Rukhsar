

const newTaskInput = document.getElementById("taskInput");
const addTaskButton = document.getElementById("addTask");
const taskList = document.getElementById("taskList");

addTaskButton.addEventListener("click", addTask);

// Load tasks from local storage when the page loads
window.addEventListener("load", loadTasks);

function addTask() {
    const taskText = newTaskInput.value.trim();

    if (taskText !== "") {
        const task = {
            id: Date.now(),
            text: taskText,
            completed: false,
        };

        tasks.push(task);
        saveTasks();

        renderTasks();

        newTaskInput.value = "";
    }
}

function deleteTask(taskId) {
    tasks = tasks.filter(task => task.id !== taskId);
    saveTasks();
    renderTasks();
}

function toggleTaskCompletion(taskId) {
    tasks = tasks.map(task => {
        if (task.id === taskId) {
            return { ...task, completed: !task.completed };
        }
        return task;
    });
    saveTasks();
    renderTasks();
}

function renderTasks() {
    taskList.innerHTML = "";

    tasks.forEach(task => {
        const taskItem = document.createElement("li");
        taskItem.className = "task";

        const taskTextElement = document.createElement("span");
        taskTextElement.textContent = task.text;

        const deleteButton = document.createElement("span");
        deleteButton.className = "delete";
        deleteButton.textContent = "Delete";
        deleteButton.addEventListener("click", () => deleteTask(task.id));

        const completeButton = document.createElement("span");
        completeButton.className = "complete";
        completeButton.textContent = task.completed ? "Unmark" : "Mark";
        completeButton.addEventListener("click", () => toggleTaskCompletion(task.id));

        taskItem.appendChild(taskTextElement);
        taskItem.appendChild(deleteButton);
        taskItem.appendChild(completeButton);

        if (task.completed) {
            taskItem.classList.add("completed");
        }

        taskList.appendChild(taskItem);
    });
}

// Save and load tasks from local storage
function saveTasks() {
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function loadTasks() {
    const savedTasks = localStorage.getItem("tasks");
    tasks = savedTasks ? JSON.parse(savedTasks) : [];
    renderTasks();
}
