

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class StudentRecordSystem {

	public static void main(String[] args) {
 
		  Scanner scanner = new Scanner(System.in);
	        Map<String, Student> studentMap = new HashMap<>();

	        while (true) {
	            System.out.println("1. Add Student | 2. View Students | 3. Exit");
	            int choice = scanner.nextInt();

	            if (choice == 1) {
	                System.out.print("Enter student name: ");
	                scanner.nextLine(); // Consume newline
	                String name = scanner.nextLine();

	                System.out.print("Enter student age: ");
	                int age = scanner.nextInt();

	                System.out.print("Enter student grade: ");
	                scanner.nextLine(); // Consume newline
	                String grade = scanner.nextLine();
	                
	                Student student = new Student(name, age, grade);
	                studentMap.put(name, student);
	                System.out.println("Student added.");
	            } else if (choice == 2) {
	                System.out.println("Students:");
	                for (Student student : studentMap.values()) {
	                    
	                	
	                	
	                    System.out.println();
	                }
	            } else if (choice == 3) {
	                break;
	            } else {
	                System.out.println("Invalid choice.");
	            }
	        }

	        System.out.println("Goodbye!");
	        scanner.close();
	    
	}
}
	
