

import jakarta.servlet.ServletException;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
 
 	@WebServlet("/RegistrationServlet")
	public class RegistrationServlet extends HttpServlet {
 		
	    public void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	    	
	        String firstName = request.getParameter("firstName");
	        String lastName = request.getParameter("lastName");
	        String email = request.getParameter("email");

	        // Store the data or perform other actions
	        // For simplicity, we're just displaying a confirmation message

	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.println("<html><body>");
	        out.println("<h2>Registration Successful</h2>");
	        out.println("<p>Thank you for registering!</p>");
	        out.println("<p>Name: " + firstName + " " + lastName + "</p>");
	        out.println("<p>Email: " + email + "</p>");
	        out.println("</body></html>");
	    }
	}
