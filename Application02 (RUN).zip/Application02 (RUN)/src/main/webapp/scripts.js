 
 
 document.getElementById("helloButton").addEventListener("click", function () {
    fetch("hello")
        .then((response) => response.text())
        .then((message) => alert(message))
        .catch((error) => console.error(error));
});
