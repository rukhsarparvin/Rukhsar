

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
 
  
	@WebServlet("/QuizServlet")
	public class QuizServlet extends HttpServlet {
		
	    private Question[] questions; // Initialize with your questions

	     public void doPost(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        int score = 0;

	        for (int i = 0; i < questions.length; i++) {
	            int userAnswer = Integer.parseInt(request.getParameter("answer_" + i));
	            if (userAnswer == questions[i].getCorrectOptionIndex()) {
	                score++;
	            }
	        }

	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        
	        out.println("<html><head><title>Quiz Result</title></head><body>");
	        out.println("<h2>Quiz Result</h2>");
	        
	        out.println("<p>Your score: " + score + " out of " + questions.length + "</p>");
	        out.println("</body></html>");
	    }
	}
