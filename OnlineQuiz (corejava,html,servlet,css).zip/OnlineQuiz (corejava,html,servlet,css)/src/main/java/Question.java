
public class Question {

	 private String questionText;
	    private String[] options;
	    private int correctOptionIndex;
	    
		public Question(String questionText, String[] options, int correctOptionIndex) {
			super();
			this.questionText = questionText;
			this.options = options;
			this.correctOptionIndex = correctOptionIndex;
		}

		public String getQuestionText() {
			return questionText;
		}

		public void setQuestionText(String questionText) {
			this.questionText = questionText;
		}

		public String[] getOptions() {
			return options;
		}

		public void setOptions(String[] options) {
			this.options = options;
		}

		public int getCorrectOptionIndex() {
			return correctOptionIndex;
		}

		public void setCorrectOptionIndex(int correctOptionIndex) {
			this.correctOptionIndex = correctOptionIndex;
		}
	    
	    
}
