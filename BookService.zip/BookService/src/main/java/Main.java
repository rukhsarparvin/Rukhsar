
 
 
import java.util.List;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.web.bind.annotation.GetMapping;
		public class Main {
			
			@GetMapping("BookService")
			public static void main(String[] args) {
		 
				
				
 		        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

  		        BookService bookService = context.getBean(BookService.class);

  		        bookService.addBook(new Book(1, "Spring in Action", "Craig Walls", 45.00));
		        bookService.addBook(new Book(2, "Effective Java", "Joshua Bloch", 55.00));

		        // Get all books and print their details
		        List<Book> books = bookService.getAllBooks();
		        for (Book book : books) {
		            System.out.println(book.getTitle() + " by " + book.getAuthor() + " - Price: $" + book.getPrice());
		        }

		        // Close the Spring context
		        context.close();
		    }

	}


