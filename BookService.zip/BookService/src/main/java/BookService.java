
 

import java.util.ArrayList;
import java.util.List;

public class BookService {

    private List<Book> books;
	public Object addBook;

    public BookService() {
        books = new ArrayList<>();
    }

    public void addBook(Book book) {
        books.add(book);
    }

    public List<Book> getAllBooks() {
        return books;
    }

    // You can add other methods for update, delete, etc., if needed.
}






