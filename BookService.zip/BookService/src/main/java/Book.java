
public class Book {

	public Book(int i, String string, String string2, double d) {
		// TODO Auto-generated constructor stub
	}
	private int id;
    private String title;
    private String author;
    private double price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getTitle1() {
		// TODO Auto-generated method stub
		return null;
	}

}
